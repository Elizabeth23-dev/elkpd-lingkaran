import { Links, Meta, Outlet, Scripts, ScrollRestoration, useNavigate } from "react-router";
import { useEffect } from "react";
import type { Route } from "./+types/root";
import colorSchemeApi from "@dazl/color-scheme/client?url";
import { ErrorBoundary as ErrorBoundaryRoot } from "~/components/error-boundary/error-boundary";
import { useColorScheme } from "@dazl/color-scheme/react";
import favicon from "/favicon.svg";

import "./styles/reset.css";
import "./styles/global.css";
import "./styles/theme.css";
import styles from "./root.module.css";

import { NavigationHeader } from "./blocks/__global/navigation-header";
import { FooterInformation } from "./blocks/__global/footer-information";
import { AuthProvider } from "./hooks/use-auth";
import { RequireAuth } from "./components/require-auth/require-auth";

export const links: Route.LinksFunction = () => [
  {
    rel: "icon",
    href: favicon,
    type: "image/svg+xml",
  },
  { rel: "preconnect", href: "https://fonts.googleapis.com" },
  {
    rel: "preconnect",
    href: "https://fonts.gstatic.com",
    crossOrigin: "anonymous",
  },
  {
    rel: "stylesheet",
    href: "https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800&family=Merriweather+Sans:wght@400;600;700&display=swap",
  },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const { rootCssClass, resolvedScheme } = useColorScheme();
  return (
    <html lang="id" suppressHydrationWarning className={rootCssClass} style={{ colorScheme: resolvedScheme }}>
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <Meta />
        <script src={colorSchemeApi} data-light-class="light-theme" data-dark-class="dark-theme"></script>
        <Links />
      </head>
      <body className={styles.body}>
        <AuthProvider>
          <header className={styles.header}>
            <NavigationHeader />
          </header>
          <main className={styles.main}>
            <RequireAuth>{children}</RequireAuth>
          </main>
          <footer className={styles.footer}>
            <FooterInformation />
          </footer>
        </AuthProvider>
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  );
}

function SpaRedirectHandler() {
  const navigate = useNavigate();
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const redirectPath = params.get("p");
    if (redirectPath) {
      const query = params.get("q");
      navigate(redirectPath + (query ? `?${query}` : ""), { replace: true });
    }
  }, [navigate]);
  return null;
}

export default function App() {
  return (
    <>
      <SpaRedirectHandler />
      <Outlet />
    </>
  );
}

export const ErrorBoundary = ErrorBoundaryRoot;
